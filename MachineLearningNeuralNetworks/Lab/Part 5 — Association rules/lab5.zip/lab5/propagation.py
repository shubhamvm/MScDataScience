from sklearn.datasets import make_classification
from sklearn.semi_supervised import LabelPropagation
from matplotlib import pyplot as plt 

nb_samples = 1000
nb_unlabeled = 750
X, Y = make_classification(n_samples=nb_samples, n_features=2, n_informative=2, n_redundant=0, random_state=100)
Y[nb_samples - nb_unlabeled:nb_samples] = -1

xla=X[Y >= 0]
yla=Y[Y >= 0]

xun=X[Y == -1]

plt.figure(0)
plt.scatter(xun[:,0],xun[:,1], marker='x',c='black')
plt.scatter(xla[:,0],xla[:,1],c=yla,marker='o')

lp = LabelPropagation(kernel='rbf', gamma=10.0)
lp.fit(X, Y)
Y_final = lp.predict(X)

plt.figure(1)
plt.scatter(X[:,0],X[:,1], c=Y_final, marker='o')


